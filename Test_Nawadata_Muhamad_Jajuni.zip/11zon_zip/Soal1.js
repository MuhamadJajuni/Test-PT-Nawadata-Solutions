function memisahkanKarakter(s) {
    let vowelPlot = '';
    let consonantChars = '';
  
    // Proses sebagai huruf kecil dan abaikan spasi
    s = s.replace(/\s/g, '').toLowerCase();
  
    for (let i = 0; i < s.length; i++) {
      let char = s[i];
      // Pemeriksaan manual untuk vokal dan konsonan
      if ('aeiou'.includes(char)) {
        vowelPlot += char;
      } else if (char >= 'a' && char <= 'z') {
        consonantChars += char;
      }
    }
  
    console.log("Vowel Characters: " + vowelPlot);
    console.log("Consonant Characters: " + consonantChars);
  }
  
  // Contoh penggunaan:
//   const S = "Sample Case";
  const S = "Next Case";
  memisahkanKarakter(S);
  