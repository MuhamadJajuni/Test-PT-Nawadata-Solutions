function busReady(n, membersUser) {
    if (n !== membersUser.length) {
      console.log("Input harus sama dengan jumlah keluarga");
      return;
    }
  
    // Mengurutkan array menurun
    for (let i = 0; i < n - 1; i++) {
      for (let j = i + 1; j < n; j++) {
        if (membersUser[i] < membersUser[j]) {
          let temp = membersUser[i];
          membersUser[i] = membersUser[j];
          membersUser[j] = temp;
        }
      }
    }
  
    let busesNeeded = 0;
    let start = 0;
    let end = n - 1;
  
    while (start <= end) {
      if (start === end) {
        busesNeeded++;
        break;
      }
  
      if (membersUser[start] + membersUser[end] <= 4) {
        end--;
      }
  
      start++;
      busesNeeded++;
    }
  
    console.log("Bus minimum yang dibutuhkan adalah: " + busesNeeded);
  }
  
  // Contoh inputan
  const n = 5;
//   const membersUser = [2, 3, 4, 4, 2, 1, 3, 1];
//   const membersUser = [ 1, 2, 4, 3, 3];
  const membersUser = [ 1, 5];
  busReady(n, membersUser);
  